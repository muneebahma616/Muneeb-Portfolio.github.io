<?PHP
    include("cartModel.php");
    include_once("Connectivity.php");

    class CartController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function insertObject(cartModel $objCart){
            try{
                $query = "INSERT into cart(customer_Email,product_id) values(:customer_Email,:product_id)";
                $objStatement = $this->connection->prepare($query);
                $customer_Email=$objCart->getCid();
                $product_id=$objCart->getproductID();
                $objStatement->bindParam(":customer_Email", $customer_Email);
                $objStatement->bindParam(":product_id", $product_id);
                $objStatement->execute();
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }
    }
?>