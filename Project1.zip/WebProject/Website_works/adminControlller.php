<?PHP
    include_once("adminModel.php");
    include_once("Connectivity.php");

    class adminController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function authenticate(adminModel $objadminModel){
            try{
                $query = "SELECT * from admin where username = :username and password = :password";
                $objStatement = $this->connection->prepare($query);
                $username = $objadminModel->getUserName();
                $password = $objadminModel->getPassword();
                
                $objStatement->bindParam(":username", $username);
                $objStatement->bindParam(":password", $password);
                $objStatement->execute();
                $record = $objStatement->fetch(PDO::FETCH_ASSOC);
                if($record){
                    $objadminModel = new adminModel($record["username"], $record["password"]);
                    return $objadminModel;
                }else{
                    return NULL;
                }
            }catch(Exception $e){
                //echo $e->getMessage();
                return NULL;
            }
        }       
    }

?>