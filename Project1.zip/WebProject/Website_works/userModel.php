<?PHP
    class UserModel
    {
        private $Email;
        private $password;

        public function __construct($Email, $password){
            $this->setUsername($Email);
            $this->setPassword($password);
        }
        public function setUsername($username){
            $this->Email = $username;
        }
        public function setPassword($password){
            $this->password = $password;
        }
        public function getUsername(){
            return $this->Email;
        }
        public function getPassword(){
            return $this->password;
        }
    }
?>