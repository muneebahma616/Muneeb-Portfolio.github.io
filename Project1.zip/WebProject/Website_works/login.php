<?php    ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Signin</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <link rel="icon" type="image/png" href="./Pictures/Logo.png" />
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
        <?php
     
        include_once("userController.php");
        include_once("userModel.php");
            $objUser = NULL;
            session_start();
            if(isset($_POST["Email"])){
                $objUserController = new UserController();

                $objUserModel = new UserModel($_POST["Email"], $_POST["password"]);
                $objUser = $objUserController->authenticate($objUserModel);
            }
         
        ?>
    
</head>

<body>
        
    <div class="container-fluid min-height default-bg">
        <p class="text-center text-white h1 pt-5">BAZAAR</p>
        <div class="container">
            <div class="center-screen-2">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6 d-lg-block d-none">
                        <p class="text-white"> Motorcycle & Engine Company is the sole division of <b>Royal Bikes</b>
                            that provides products directly to
                            general consumers. The company manufactures a broad range of products, including motorcycle,
                            off-road four wheeler, watercraft "JET SKI®", and general-purpose gasoline engines; and
                            supplies
                            them to markets around the world.
                        </p>
                    </div>
                    <div class="col-lg-6">
                        <div class="bg-white p-5 rounded-3 position-relative">
                            <p class="text-center h3 mb-3 mt-3">Signin</p>
                            <form method="POST" class="row">
                                <div class="col-12 mb-3">
                                    <label for="">Email</label>
                                    <input type="email" name="Email" class="form-control mt-2" placeholder="Enter Email" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Password</label>
                                    <input type="password" name="password" class="form-control mt-2" placeholder="Enter Password" required>
                                    <?PHP
                                         if(isset($_POST["Email"])){
                                         if($objUser == NULL){
                                        echo "You have entered invalid username or password";
                                        }else{
                                            
                                        $_SESSION["Email"] = $_POST["Email"];
                                        header("Location: ./home.php");
                                        }
                                    }
                                    ?>
                                </div>
                                <div class="col-12">
                                    <div class="text-center">
                                        <button class="btn btn-outline-warning px-5 py-2 hover-btn" type="submit">Signin</button>
                                    </div>
                                </div>
                            </form>
                            <div class="text-center mt-3">
                                <a href="./index.php">
                                    <button class="btn text-warning hover-underline-animation"> Create an Account</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</body>

</html>
<?php      ob_end_flush(); ?>