<?PHP
class ReviewModel
{
    private $comment;
    private $customer_Email;
    private $img;
    public function __construct($customer_Email = "", $comment = "", $img ="")
    {
        $this->setComment($comment);
        $this->setCustomerEmail($customer_Email);
        $this->setImg($img);
    }
    public function setComment($comment)
    {
        $this->comment = $comment;
    }
    public function setCustomerEmail($customer_Email)
    {
        $this->customer_Email = $customer_Email;
    }
    public function getComment()
    {
        return $this->comment;
    }
    public function getCustomerEmail()
    {
        return $this->customer_Email;
    }

    public function setImg($img)
    {
        $this->img = $img;
    }
    public function getImg()
    {
        return $this->img;
    }
}
?>