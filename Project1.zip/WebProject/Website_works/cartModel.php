<?PHP
    class CartModel{

        private $customer_Email;
        private $product_id;
        public function __construct($customer_Email="",$product_id=""){
            $this->setcustomerID($customer_Email);
            $this->setproductID($product_id);
        }
        public function setcustomerID($customer_Email){
            $this->customer_Email = $customer_Email;
        }
        public function setproductID($p){
            $this->product_id = $p;
        }
        public function getCid(){
            return $this->customer_Email;
        }
        public function getproductID(){
            return $this->product_id;
        }
    }
?>