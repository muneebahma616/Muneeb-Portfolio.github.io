<?php   ob_start(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Home</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <link rel="icon" type="image/png" href="./Pictures/Logo.png" />
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- Font Awesome v`6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php
  
    include("reviewController.php");
    $objreviewController = new ReviewController();
    $objreviewlist = array();
    if (isset($_POST["Email"]))
        $objreviewlist = $objreviewController->searchReview($_REQUEST["Email"]);
       
    ?>
</head>

<body style="background: #eee;">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <div class="container">
        <div class="Menu-bar">
            <h2>Admin Options</h2>
            <br>
            <ul>
                <li><a href="#"><i class="fas fa-plus"></i>Add Product</a></li>
                <li><a href="#"><i class="fas fa-search"></i><span id="Search">Check Feedback</span></a>
            </ul>
        </div>

        <form method="POST" class="Search-form">
            <h4> Search Feedback by Email </h4>
            <input type="text" id="Email" name="Email" placeholder="Enter Email" class="credentials">
            <input type="submit" id="Email" name="search" value="Search" class="Search-btn">
        </form>
        <div>
            <table class="table table-bordered">
                <tr>
                    <th>Comments</th>
                    <th>Picture</th>
                </tr>
                <?php
                if ($objreviewlist != NULL) {
                    foreach ($objreviewlist as $objreviewModel) {
                        echo "<tr><td>" . $objreviewModel->getComment() . "</td>";
                        if ($objreviewModel->getImg() != null) {
                            $data_url = "data:image/jpeg;base64," . base64_encode($objreviewModel->getImg());
                            echo "<td><img src='" . $data_url . "' width='100px' height='150px'></td>";
                        }
                        echo "</tr>";
                    }
                }
                ?>
            </table>
        </div>
    </div>
</body>

</html>

<?php  ob_end_flush(); ?>