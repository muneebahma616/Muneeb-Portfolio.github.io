<?PHP
    include_once("CustomerModel.php");
    include("Connectivity.php");

    class CustomerController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function insertCustomer(CustomerModel1 $objCustomerModel){
            try{
                $query = "INSERT INTO customer(name,City,phone,Email,password) values(:name,:City,:phone,:Email,:password)";
                $objStatement = $this->connection->prepare($query);
                $name = $objCustomerModel->getName();
                $City=$objCustomerModel->getCity();
                $phone=$objCustomerModel->getPhoneNo();
                $Email=$objCustomerModel->getEmail();
                $password=$objCustomerModel->getPassword();
                $objStatement->bindParam(":name", $name);
                $objStatement->bindParam(":City", $City);
                $objStatement->bindParam(":phone", $phone);
                $objStatement->bindParam(":Email", $Email);
                $objStatement->bindParam(":password", $password);
                $objStatement->execute();
            }
            catch(Exception $e){
                echo $e->getMessage();
            }
        }     
    }
?>