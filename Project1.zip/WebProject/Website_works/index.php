<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    
    include_once("CustomerController.php");
    include_once("CustomerModel.php");
    include_once("userModel.php");
    include_once("userController.php");
    $objCustomerController=new CustomerController();
    $objuserController=new UserController();
    if(isset ($_POST["Fullname"])){
        $objCustomerModel=new CustomerModel1($_REQUEST["Fullname"],$_REQUEST["City"],$_REQUEST["Phone"],
        $_REQUEST["Email"],$_REQUEST["password"],$_REQUEST["cpassword"]);
        $objCustomerController->insertCustomer($objCustomerModel);

        $objuserModel=new UserModel($_REQUEST["Email"],$_REQUEST["password"]);
        $objuserController->insertUser($objuserModel);
        header("Location:./login.php");
        exit();
    }
 
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Signup</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <link rel="icon" type="image/png" href="./Pictures/Logo.png"/>
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">    
</head>

<body>
    <div class="container-fluid min-height default-bg">
        <p class="text-center text-white h1 pt-5">BAZAAR</p>
        <div class="container">
            <div class="center-screen">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6 d-lg-block d-none">
                        <p class="text-white">BAZAAR.pk is known for its large volume of motorbike sales but we
                            buy thousands of motorbikes a year from the general public. The team at Royal Bikes all ride
                            bikes this
                            makes it easy for us to understand each bike and correctly value your pride and joy. The
                            valuation service is extremely easy and we do all the hard work for you. We collect your
                            details via the
                            form above and the team of bikers assess the bike over the phone, via email or text. We
                            gather as
                            much detail as possible and once a price is agreed we arrange for a FREE collection! The
                            whole
                            process can be as quick as a 24 hour turnaround. Let's talk money, we can do a free instant
                            transfer
                            into your account.
                        </p>
                    </div>
                    <div class="col-lg-6">
                        <div class="bg-white p-5 rounded-3 position-relative">
                            <p class="text-center h3 mb-3 mt-3">Register Now</p>
                            <form  method="POST" class="row" id="customerRegister">
                                <div class="col-12 mb-3">
                                    <label for="">Full Name</label>
                                    <input type="name" name="Fullname" class="form-control" id="name" placeholder="e.g. Asif Ali" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">City</label>
                                    <input type="text" name="City" class="form-control" placeholder="e.g. Lahore, Pakistan" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Phone Number</label>
                                    <input type="text" name="Phone" class="form-control" placeholder="+92XXXXXXXXXX" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Email</label>
                                    <input type="text" name="Email" class="form-control" placeholder="e.g. abc@gmail.com" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Password</label>
                                    <input type="password"  name="password" class="form-control" placeholder="Enter Password"  required>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Confirm Password</label>
                                    <input type="password" name="cpassword" class="form-control" placeholder="Confirm Password"  required>
                                </div>
                                <div class="col-12">
                                    <div class="text-center">
                                        <button class="btn btn-outline-warning px-5 py-2 hover-btn" type="submit" id="submit">Signup</button>
                                    </div>
                                </div>
                            </form>
                            <div class="text-center mt-3">
                                <a href="./login.php">
                                    <button class="btn text-warning hover-underline-animation"> Already have an Account</button>
                                </a>
                                <a href="./AdminLogin.php">
                                    <button class="btn text-warning hover-underline-animation">Admin</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php    ob_end_flush(); ?>