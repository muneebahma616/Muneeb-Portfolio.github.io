<?PHP
    class orderModel{
        private $cart_id;
        public function __construct($cart_id=""){
            $this->cart_id=$cart_id;
        }
        public function setCartid($n)
        {
            $this->cart_id=$n;
        }
        public function getCartid()
        {
            return $this->cart_id;
        }
    }
?>