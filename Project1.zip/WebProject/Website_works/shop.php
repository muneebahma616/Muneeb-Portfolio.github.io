<?php session_start();
   ob_start();?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Home</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <link rel="icon" type="image/png" href="./Pictures/Logo.png" />
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- Font Awesome v`6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <?php
 
    // $_SESSION("ProductId") = NULL;
    include_once("cartController.php");
    include_once("cartModel.php");
    include_once("orderController.php");
    $objcartController=new CartController();
    $objorderController=new orderController();
    if (isset($_REQUEST['P-id'])) {
        $_SESSION["P-ID"] = $_REQUEST['P-id'];
        $email=$_SESSION['Email'];
        $objcartModel=new CartModel($email,$_REQUEST['P-id']);
        $objcartController->insertObject($objcartModel);
        if($objcartModel->getCid()!=NULL)
        {
            $objorderController->insertObject($objcartModel->getCid());
        }
    }
  
    ?>
    <form method="post">
        <input type="hidden" name="P-id" id="P-id" value="">
        <nav class="navbar navbar-expand-lg navbar-light bg-light  justify-content-between">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                    <ul class="navbar-nav mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link  hover-underline-animation" aria-current="page"
                                href="./home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link link-active hover-underline-animation" aria-current="page"
                                href="./shop.php">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link hover-underline-animation" aria-current="page"
                                href="./contactus.php">Contact
                                Us</a>
                        </li>
                    </ul>
                    <div class="d-md-none d-block">
                        <a href="./login.php">
                            <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                        </a>
                    </div>
                </div>
                <div class="d-lg-flex justify-content-end d-none">
                    <a href="./login.php">
                        <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                    </a>
                </div>
            </div>
        </nav>

        <div class="container-fluid default-bg p-5">
            <div class="container">
                <div class="text-center">
                    <h1 class="text-center hover-underline-animation text-white text-uppercase fw-bold">Shop</h1>
                    <div class="row mt-4">
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P1image" class="card-img-top" src="./Pictures/BMW_S1000RR.png">
                                <div class="card-body">
                                    <h5 name="P1name" class="card-title text-white text-white">BMW S1000RR</h5>
                                    <button id="1" onclick="sendProduct(this)" name="P 1button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P1price">$60,000</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P2image" class="card-img-top" src="./Pictures/Kawasaki_Ninja_H2R.png">
                                <div class="card-body">
                                    <h5 name="P2name" class="card-title text-white text-white">Kawasaki Ninja H2R</h5>
                                    <button id="2" onclick="sendProduct(this)" name="P2button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P2price">$120,000</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P3image" class="card-img-top" src="./Pictures/Yamaha_R1__YZF.png">
                                <div class="card-body">
                                    <h5 name="P3name" class="card-title text-white text-white">Yamaha YZF-R1</h5>
                                    <button id="3" onclick="sendProduct(this)" name="P3button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P3price">$70,000
                                        <p>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P4image" class="card-img-top" src="./Pictures/kn-250.png">
                                <div class="card-body">
                                    <h5 name="P4name" class="card-title text-white text-white">Kawasaki Ninja 250r</h5>
                                    <button id="4" onclick="sendProduct(this)" name="P4button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P4price">$50,000</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P5image" class="card-img-top" src="./Pictures/Yamaha_R6__YZF.png">
                                <div class="card-body">
                                    <h5 name="P5image" class="card-title text-white text-white">Kawasaki Ninja 250r</h5>
                                    <button id="5" onclick="sendProduct(this)" name="P5button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P5price">$80,000</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mb-3">
                            <div class="card default-bg-2" style="width: 100%;">
                                <img name="P6image" class="card-img-top" src="./Pictures/k1.png">
                                <div class="card-body">
                                    <h5 name="P6name" class="card-title text-white text-white">Kawasaki Ninja ZX 14R
                                    </h5>
                                    <button id="6" onclick="sendProduct(this)" name="P6button"
                                        class="btn btn-outline-light px-3 py-2 rounded-pill hover-btn-y">Buy -
                                        <p name="P6price">$100,000</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="container-fluid default-bg">
            <div class="container p-5">
                    <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                        <h5 class="default-color hover-underline-animation">Pages</h5>
                        <p class="mb-0">
                            <a class="btn text-white" href="./home.php">Home</a>
                        </p>
                        <p class="mb-0">
                            <a class="btn text-white" href="./index.php">Sales</a>
                        </p>
                        <p class="mb-0">
                            <a class="btn text-white" href="./index.php">Purchase</a>
                        </p>
                        <p class="mb-0">
                            <a class="btn text-white" href="./index.php">Contact Us</a>
                        </p>
                    </div>
                    <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                        <h5 class="default-color hover-underline-animation">Follow Us</h5>
                        <div class="d-flex">
                            <a class="btn" href="http://www.facebook.com" style="font-size: 20px;">
                                <i class="fab text-white fa-facebook-f"></i>
                            </a>
                            <a class="btn" href="http://www.instagram.com" style="font-size: 20px;">
                                <i class="fab text-white fa-instagram"></i>
                            </a>
                            <a class="btn" href="http://www.twitter.com" style="font-size: 20px;">
                                <i class="fab text-white fa-twitter"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                        <h5 class="default-color hover-underline-animation">Address</h5>
                        <p class="text-white">
                            Location: 123 Main St. Suite 100, San Francisco CA 93106
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </form>
    <script src="./js/bootstrap.min.js"></script>
    <script>
        function sendProduct(input) {
            console.log(input.id)
            document.getElementById('P-id').value = input.id
        }
    </script>
</body>

</html>
<?php
ob_end_flush(); ?>