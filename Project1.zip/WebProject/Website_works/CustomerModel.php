<?PHP
    class CustomerModel1{

        private $C_name;
        private $C_City;
        private $phone_no;
        private $Email;
        private $password;
        private $confirmPassword;
        public function __construct($C_name = "",$C_City="", $phone_no="", $Email="",$password="",$confirmPassword=""){
            $this->C_name=$C_name;
            $this->C_City=$C_City;
            $this->phone_no=$phone_no;
            $this->Email=$Email;
            $this->password=$password;
            $this->confirmPassword=$confirmPassword;
        }
        public function setName($n)
        {
            $this->C_name=$n;
        }
        public function setCity($c)
        {
            $this->C_City=$c;
        }
        public function setPhoneNo($p)
        {
            $this->phone_no=$p;
        }
        public function setEmail($E)
        {
            $this->Email=$E;
        }
        public function setPassword($Pa)
        {
            $this->password=$Pa;
        }
        public function setConfirmPassword($Cp)
        {
            $this->confirmPassword=$Cp;
        }
        public function getName()
        {
            return $this->C_name;
        }
        public function getCity()
        {
            return $this->C_City;
        }
        public function getPhoneNo()
        {
            return $this->phone_no;
        }
        public function getEmail()
        {
            return $this->Email;
        }
        public function getPassword()
        {
            return $this->password;
        }
        public function getConfirmPassword()
        {
            return $this->confirmPassword;
        }
    }

?>