<?PHP
    include_once("customerQueryModel.php");
    include_once("Connectivity.php");

    class customerQueryController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function insertReview(customerQuery $objcustomerQueryModel){
                $query = "INSERT INTO Review(Email,Comment) values(:Email,:Comment)";
                $objStatement = $this->connection->prepare($query);
                $Email = $objcustomerQueryModel->getCustomerEmail();
                $Comment=$objcustomerQueryModel->getComment();
                $objStatement->bindParam(":Email", $Email);
                $objStatement->bindParam(":Comment", $Comment);
                $objStatement->execute();
        }
    }
?>