<?php  ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Home</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <link rel="icon" type="image/png" href="./Pictures/Logo.png" />
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- Font Awesome v6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php
   
    include("ReviewController.php");
    include_once("reviewModel.php");
    $objReviewController = new ReviewController();
    if (isset($_POST["Email"])) {
        $Photo = fopen($_FILES["photo"]["tmp_name"], "rb");
        $PhotoData = fread($Photo, $_FILES["photo"]["size"]);
        $objreviewModel = new ReviewModel($_REQUEST["Email"], $_REQUEST["message"], $PhotoData);
        $objReviewController->insertReview($objreviewModel);
        header("Location:./home.php");
        exit();
    }
  
    ?>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light  justify-content-between">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <ul class="navbar-nav mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link hover-underline-animation" aria-current="page" href="./home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hover-underline-animation" aria-current="page" href="./shop.php">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link link-active hover-underline-animation" aria-current="page"
                            href="./contactus.php">Contact Us</a>
                    </li>
                </ul>
                <div class="d-md-none d-block">
                    <a href="./login.php">
                        <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                    </a>
                </div>
            </div>
            <div class="d-lg-flex justify-content-end d-none">
                <a href="./login.php">
                    <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                </a>
            </div>
        </div>
    </nav>
    <div class="container-fluid default-bg p-5">
        <div class="text-center">
            <p class="h1 text-center text-warning text-uppercase fw-bold hover-underline-animation">
                feel free to contact us
            </p>
        </div>
        <div class=" mt-5">
            <div class="row d-flex align-items-center">
                <div class="col-lg-6 col-12 d-md-block text-center d-none text-white mb-3">
                    <span class="text-warning fw-bold">BAZAAR</span> is here to help answer questions about us and
                    our products. We offer a variety of
                    options and resources to help you find the answers you are looking for. Our knowledge base will
                    provide you with answers to our most frequently asked questions. The online chat feature will
                    provide you with instant access to one of our highly trained Customer Care staff for quick
                    assistance. You will also find the online contact form to send us a message and the phone number
                    to
                    our Customer Care team.
                </div>
                <div class="col-lg-6 col-12 col-12">
                    <div class="bg-white rounded-3 p-4">
                        <form method="POST" class="container" enctype="multipart/form-data">
                            <label class="mb-2" for="">Email</label>
                            <input type="email" name="Email" placeholder="Your Email" class="form-control mb-3"
                                required>
                            <label class="mb-2" for="">Message</label>
                            <textarea style="resize: none;" name="message" class="form-control mb-3"
                                placeholder="Message/Query" name="" id="" cols="30" rows="10" required></textarea>
                            <input type="file" name="photo" accept=".jpeg" required="required">
                            <div class="text-center">
                                <button type="submit"
                                    class="btn btn-outline-warning text-uppercase py-2 px-5 rounded-pill hover-btn">submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="container-fluid default-bg">
        <div class="container p-5">
            <div class="row d-flex align-items-center">
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Pages</h5>
                    <p class="mb-0">
                        <a class="btn text-white" href="./home.php">Home</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Sales</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Purchase</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Contact Us</a>
                    </p>
                </div>
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Follow Us</h5>
                    <div class="d-flex">
                        <a class="btn" href="http://www.facebook.com" style="font-size: 20px;">
                            <i class="fab text-white fa-facebook-f"></i>
                        </a>
                        <a class="btn" href="http://www.instagram.com" style="font-size: 20px;">
                            <i class="fab text-white fa-instagram"></i>
                        </a>
                        <a class="btn" href="http://www.twitter.com" style="font-size: 20px;">
                            <i class="fab text-white fa-twitter"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Address</h5>
                    <p class="text-white">
                        Location: 123 Main St. Suite 100, San Francisco CA 93106
                    </p>
                </div>
            </div>
        </div>
    </section>
    <script src="./js/bootstrap.min.js"></script>
</body>

</html>
<?php   ob_end_flush(); ?>