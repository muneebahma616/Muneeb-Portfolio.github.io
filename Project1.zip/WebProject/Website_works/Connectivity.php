<?PHP
    class Connectivity{
        private $connection;
        public function __construct(){
            $this->connection = new PDO("mysql:host=localhost;dbname=id20263049_projectweb", "root", "");
            $this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); // Enabling the database exceptions on PHP
        }
        public function getConnection(){
            return $this->connection;
        }
    }

?>

 