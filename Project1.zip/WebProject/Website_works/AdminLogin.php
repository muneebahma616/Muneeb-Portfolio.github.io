<?php ob_start(); ?>
<html>
    <head>
        <title>
            BAZAAR.pk | Register
          </title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="Style1.css">
        <?php
        
        include_once("adminControlller.php");
        include_once("adminModel.php");
            $objUser = NULL;
            session_start();
            if(isset($_POST["username"])){
                $objadminController = new adminController();

                $objadminModel = new adminModel($_POST["username"], $_POST["password"]);
                $objUser = $objadminController->authenticate($objadminModel);
            }
            
        ?>
    
    </head>
    <body>
      <header class="header">
        <a  class="logo" >
            <h1 style="color:white">
            BAZAAR.pk
           </h1>
        </a>
       </header>
    <div style="color:black" class="Admin-login">
        <div class="form">
            <h1 style="color:black">
                Admin Login
            </h1>
            <form method="POST">
               <input type="username" id="username" name="username" required placeholder="Enter username"><br>
               <input type="password"  id="password" name="password" required placeholder="Password">
               <?PHP
                    if(isset($_POST["username"])){
                        if($objUser == NULL){
                            echo "You have entered invalid username or password";
                        }else{
                            $_SESSION["username"] = $_POST["username"];
                            header("Location: ./admin.php");
                        }
                    }
                ?>
             <button value="Login" type="submit">
                Login
             </button>
           </form>
        </div>
    </div>
    </body>
</html>

<?php ob_end_flush(); ?>