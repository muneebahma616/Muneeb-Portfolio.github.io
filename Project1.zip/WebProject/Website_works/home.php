<?php      ob_start() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZAAR.pk - Home</title>
    <link rel="stylesheet" href="./Stylesheet/style.css">
    <link rel="stylesheet" href="./Stylesheet/style2.css">
    <!-- Poppins Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- Font Awesome v6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <?php
   
        include_once("customerQueryModel.php");
        include_once("customerQueryController.php");
        $objcustomerQueryController=new customerQueryController();
        if(isset($_POST["queryemail"]))
        {
            $objcustomerQueryModel=new customerQuery($_REQUEST["queryemail"],$_REQUEST["querymessage"]);
            $objcustomerQueryController->insertReview($objcustomerQueryModel);
        }
       
        ?>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light  justify-content-between">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <ul class="navbar-nav mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link link-active hover-underline-animation" aria-current="page"
                            href="./home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hover-underline-animation" aria-current="page" href="./shop.php">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hover-underline-animation" aria-current="page" href="./contactus.php">Contact
                            Us</a>
                    </li>
                </ul>
                <div class="d-md-none d-block">
                    <a href="./login.php">
                        <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                    </a>
                </div>
            </div>
            <div class="d-lg-flex justify-content-end d-none">
                <a href="./login.php">
                    <button class="btn btn-outline-warning hover-btn rounded-pill px-5 py-2">Logout</button>
                </a>
            </div>
        </div>
    </nav>
    <div id="slider" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="./Pictures/home-1.jpg" class="d-block w-100">
                <div class="text-img-center">
                    <p class="text-warning text-white h1">
                        <span class="text-warning fw-bold"> Riding</span> a race bike
                        is an art - a thing that you do
                        because you feel something inside.
                    </p>
                </div>
            </div>
            <div class="carousel-item ">
                <img src="./Pictures/home-2.jpg" class="d-block w-100">
                <div class="text-img-center">
                    <p class="text-white text-center h1"> If you want to be happy for a day, if you want to be happy
                        for a year, Marry. If you want to be happy for a lifetime,
                        <span class="text-warning fw-bold">Ride a Bike.</span>
                    </p>
                </div>
            </div>
            <div class="carousel-item ">
                <img src="./Pictures/home-3.jpg" class="d-block w-100">
                <div class="text-img-center">
                    <p class="text-white text-center h1">
                        <span class="text-warning fw-bold">FEAR</span> - Forget Everything and Ride.
                    </p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#slider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#slider" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <section class="container-fluid default-bg">
        <div class="container p-5">
            <div class="text-center">
                <h1 class="text-warning text-center hover-underline-animation text-uppercase fw-bold">Hot Products</h1>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card" style="background-color: transparent; width: 100%;">
                        <img class="card-img-top" src="./Pictures/k1.png">
                        <div class="card-body">
                            <h5 class="card-title text-warning hover-underline-animation">Kawasaki Ninja ZX 14R</h5>
                            <p class="card-text text-white">
                                It still sports its legendary 1441cc in-line four-cylinder engine, which produces a
                                beefy 207.9 hp and
                                113.2 lb-ft of torque. Other major features on the bike include Kawasaki Traction
                                Control, multiple
                                power modes, and Brembo 4-piston M50 monobloc calipers.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card" style="background-color: transparent; width: 100%;">
                        <img class="card-img-top" src="./Pictures/kn-250.png">
                        <div class="card-body">
                            <h5 class="card-title text-warning hover-underline-animation">Kawasaki Ninja 250r</h5>
                            <p class="card-text text-white">
                                This new model of Kawasaki 250R heavy-bike is coming in two different variants; i.e.
                                EX250L (non-ABS
                                brakes version) and EX250M (with ABS brakes version). There is no major difference in
                                their designs but
                                a few specs differ lies among both.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-5">
                    <div class="text-center">
                        <a href="./purchase.php">
                            <button class="btn btn-outline-warning text-white rounded-pill px-5 py-2">Shop Now</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="container-fluid default-bg-2">
        <div class="container p-5">
            <div class="text-center">
                <h1 class="text-center hover-underline-animation text-white text-uppercase fw-bold">Our Services</h1>
                <p class="text-center text-white lead mt-5">
                    BAZAAR is known for its large volume of motorbike sales but we buy thousands of motorbikes a
                    year from the general public. The team at Royal Bikes all ride bikes this makes it easy for us to
                    understand each bike and correctly value your pride and joy. The valuation service is extremely easy
                    and we do all the hard work for you. We collect your details via the form above and the team of
                    bikers assess the bike over the phone, via email or text. We gather as much detail as possible and
                    once a price is agreed we arrange for a FREE collection! The whole process can be as quick as a 24
                    hour turnaround. Let's talk money, we can do a free instant transfer into your account.
                </p>
                <p class="text-center lead text-white mt-2"> Motorcycle & Engine Company is the sole division of
                    <b>BAZAAR</b> that provides products
                    directly to general consumers. The company manufactures a broad range of products, including
                    motorcycle,
                    off-road four wheeler, watercraft "JET SKI®", and general-purpose gasoline engines; and supplies
                    them to markets around the world.
                </p>
            </div>
        </div>
    </section>

    <section class="container-fluid default-bg">
        <div class="container p-5">
            <div class="text-center">
                <h1 class="text-warning text-center hover-underline-animation fw-bold text-uppercase">Feel free to
                    Contact Us</h1>
            </div>
            <div class="bg-white rounded-3 p-5">
                <form method="POST" class="container">
                    <label class="mb-2" for="">Email</label>
                    <input name="queryemail" type="email" placeholder="Your Email" class="form-control mb-3">
                    <label class="mb-2" for="">Message</label>
                    <textarea name="querymessage" style="resize: none;" class="form-control mb-3" placeholder="Message/Query" name="" id=""
                        cols="30" rows="10"></textarea>
                    <div class="text-center">
                        <button type="submit"
                            class="btn btn-outline-warning text-uppercase py-2 px-5 rounded-pill hover-btn">submit</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <section class="container-fluid default-bg">
        <div class="container p-5">
            <div class="row d-flex align-items-center">
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Pages</h5>
                    <p class="mb-0">
                        <a class="btn text-white" href="./home.php">Home</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Sales</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Purchase</a>
                    </p>
                    <p class="mb-0">
                        <a class="btn text-white" href="./index.php">Contact Us</a>
                    </p>
                </div>
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Follow Us</h5>
                    <div class="d-flex">
                        <a class="btn" href="http://www.facebook.com" style="font-size: 20px;">
                            <i class="fab text-white fa-facebook-f"></i>
                        </a>
                        <a class="btn" href="http://www.instagram.com" style="font-size: 20px;">
                            <i class="fab text-white fa-instagram"></i>
                        </a>
                        <a class="btn" href="http://www.twitter.com" style="font-size: 20px;">
                            <i class="fab text-white fa-twitter"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-12 mb-lg-0 mb-3">
                    <h5 class="default-color hover-underline-animation">Address</h5>
                    <p class="text-white">
                        Location: 123 Main St. Suite 100, San Francisco CA 93106
                    </p>
                </div>
            </div>
        </div>
    </section>

    <script src="./js/bootstrap.min.js"></script>
</body>

</html>

<?php  ob_end_flush(); ?>