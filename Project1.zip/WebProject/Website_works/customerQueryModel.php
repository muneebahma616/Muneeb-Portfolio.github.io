<?PHP
    class customerQuery{
        private $comment;
        private $customer_Email;
        public function __construct($customer_Email="",$comment=""){
            $this->setComment($comment);
            $this->setCustomerEmail($customer_Email);             
        }
        public function setComment($comment){
            $this->comment = $comment;
        }
        public function setCustomerEmail($customer_Email){
            $this->customer_Email = $customer_Email;
        } 
        public function getComment(){
            return $this->comment;
        }
        public function getCustomerEmail(){
            return $this->customer_Email;
        }
    }    
?>