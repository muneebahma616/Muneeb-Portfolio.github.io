<?PHP
    include("orderModel.php");
    include_once("Connectivity.php");

    class orderController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function insertObject($email){
            try{
                $query = "INSERT into orders(cart_id) values(:cart_id)";
                $objStatement = $this->connection->prepare($query);
                $objStatement->bindParam(":cart_id", $email);
                $objStatement->execute();
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }
    }
?>