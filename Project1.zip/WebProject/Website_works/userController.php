<?PHP
    include_once("UserModel.php");
    include_once("Connectivity.php");
    include_once("CustomerModel.php");

    class UserController{
        private $connection;
        public function __construct(){
            $objDatabaseConnectivity = new Connectivity();
            $this->connection = $objDatabaseConnectivity->getConnection();
        }
        public function insertUser(UserModel $objUserModel){
            try{
                $query = "INSERT INTO User(Email,password) values(:Email,:password)";
                $objStatement = $this->connection->prepare($query);
                $Email = $objUserModel->getUsername();
                $password = $objUserModel->getPassword();
                
                $objStatement->bindParam(":Email", $Email);
                $objStatement->bindParam(":password", $password);
                
                $objStatement->execute();
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }
        public function authenticate(UserModel $objUserModel){
            try{
                $query = "SELECT * from User where Email = :Email and password = :password";
                $objStatement = $this->connection->prepare($query);
                $Email = $objUserModel->getUsername();
                $password = $objUserModel->getPassword();
                
                $objStatement->bindParam(":Email", $Email);
                $objStatement->bindParam(":password", $password);
                $objStatement->execute();
                $record = $objStatement->fetch(PDO::FETCH_ASSOC);
                if($record){
                    $objUserModel = new UserModel($record["Email"], $record["password"]);
                    return $objUserModel;
                }else{
                    return NULL;
                }
            }catch(Exception $e){
                //echo $e->getMessage();
                return NULL;
            }
        }
        
       
    }
?>