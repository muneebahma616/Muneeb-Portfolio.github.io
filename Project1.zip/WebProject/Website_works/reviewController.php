<?PHP
include("reviewModel.php");
include_once("Connectivity.php");

class ReviewController
{
    private $connection;
    public function __construct()
    {
        $objDatabaseConnectivity = new Connectivity();
        $this->connection = $objDatabaseConnectivity->getConnection();
    }
    public function insertReview(ReviewModel $objReviewModel)
    {
        $query = "INSERT INTO Review(Email,Comment,img) values(:Email,:Comment,:img)";
        $objStatement = $this->connection->prepare($query);
        $Email = $objReviewModel->getCustomerEmail();
        $Comment = $objReviewModel->getComment();
        $photo = $objReviewModel->getImg();
        $objStatement->bindParam(":Email", $Email);
        $objStatement->bindParam(":Comment", $Comment);
        $objStatement->bindParam(":img", $photo, PDO::PARAM_LOB);
        $objStatement->execute();
    }
    public function getreviewBySid($sid)
    {
        try {
            $query = "SELECT * FROM review WHERE Email=:sid";
            $objStatement = $this->connection->prepare($query);
            $objStatement->bindParam(":Email", $sid);
            $objStatement->execute();
            $record = $objStatement->fetch(PDO::FETCH_ASSOC);
            $objreviewModel = new reviewModel();
            $objreviewModel->setcustomerEmail($record["Email"]);
            $objreviewModel->setComment($record["Comment"]);
            if ($record["img"] == null) {
                $objreviewModel->setImg(null);
            } else
                $objreviewModel->setImg($record["img"]);
            return $objreviewModel;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    public function searchReview($Email)
    {
        try {
            $query = "SELECT * FROM review WHERE Email=:Email";
            $objStatement = $this->connection->prepare($query);
            $objStatement->bindParam(":Email", $Email);
            $objStatement->execute();
            $reviewList = $objStatement->fetchAll();
            $objreviewList = array();
            foreach ($reviewList as $record) {
                $objreviewModel = new reviewModel();
                $objreviewModel->setCustomerEmail($record["Email"]);
                $objreviewModel->setComment($record["Comment"]);
                $objreviewModel->setImg($record["img"]);
                $objreviewList[] = $objreviewModel;
            }
            if ($objreviewList == NULL) {
                return NULL;
            }
            return $objreviewList;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}
?>